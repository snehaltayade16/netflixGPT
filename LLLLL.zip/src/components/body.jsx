import Login from './login'
import Browse from './browse'
const Body=()=>
{
    return(

        <div>
           <Login/>
           <Browse/>
        </div>
        
    )
}
export default Body