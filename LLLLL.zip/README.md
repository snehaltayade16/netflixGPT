# React + Vite

Login
   -sign In /Sign Up form
   -redirect to brower page

browser (After login)
    -header
    -Main Movie
        -tailer in background
        -title & descripation
        -Movie suggestion
           -Movie List

netfilxgpt
    -Search Bar
    -movie suggestion


#   n e t f l i x G P T  
 